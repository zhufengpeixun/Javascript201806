let  http = require("http");
let url = require("url");
let path = require("path");

http.createServer(function (req,res) {
  // 解决跨域问题；
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Content-Length, Authorization, Accept,X-Requested-With");
  res.setHeader("Access-Control-Allow-Methods", "PUT,POST,GET,DELETE,OPTIONS");
  res.setHeader("X-Powered-By", ' 3.2.1')
  if (req.method == "OPTIONS") return res.end();

  let {pathname,query} = url.parse(req.url,true);
  // 请求轮播图数据；
  if(pathname==="/sliders"){
    let  data = require("./sliders.js");
    res.setHeader("Content-Type","application:json;charset=utf-8");
    return  res.end(JSON.stringify(data));
  }



}).listen(3000,function () {
   console.log("启动成功");
});
