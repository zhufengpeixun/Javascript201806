import React from "react";
export default class SliderItems extends  React.Component{
    render(){
        return (<ul></ul>)
    }
}