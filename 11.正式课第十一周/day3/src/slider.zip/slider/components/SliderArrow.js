import React from "react";
export default class SliderArrow extends  React.Component{
    render(){
        return (<div></div>)
    }
}