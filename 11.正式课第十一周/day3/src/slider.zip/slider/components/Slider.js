// 当前JS存储当前轮播图基础的结果；
import React from "react";
import SliderItems from "./SliderItems"
export default class Slider extends React.Component{
    render(){
        return (<div>
            <SliderItems/>
        </div>)
    }
}
